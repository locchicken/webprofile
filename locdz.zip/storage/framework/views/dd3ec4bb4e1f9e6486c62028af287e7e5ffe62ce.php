;
<?php $__env->startSection('content_main'); ?>
<div class="row">
            <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Cập nhập sản phẩm
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <?php $__currentLoopData = $show_update; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form role="form" action="<?php echo e(URL::to('/update-data-product/'.$data->product_id)); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tên sản phẩm</label>
                                    <input type="text" class="form-control" name="product_name" value="<?php echo e($data->product_name); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Hình ảnh</label>
                                    <input type="file" class="form-control" name="product_image">
                                    <img src="<?php echo e(URL::to('public/upload/product/'.$data->product_image)); ?>" width="70" height="70">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Giá sản phẩm</label>
                                    <input type="text" class="form-control" name="product_price" value="<?php echo e($data->product_price); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputFile">Danh mục sản phẩm</label>
                                    <select name="cate" class="form-control m-bot15">
                                        <?php $__currentLoopData = $cate_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data_cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($data_cate->category_id==$data->category_id): ?>
                                            <option selected value="<?php echo e($data_cate->category_id); ?>"><?php echo e($data_cate->category_name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($data_cate->category_id); ?>"><?php echo e($data_cate->category_name); ?></option>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputFile">Thương hiệu sản phẩm</label>
                                    <select name="brand" class="form-control m-bot15">
                                        <?php $__currentLoopData = $brand_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data_brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($data_brand->brand_id==$data->brand_id): ?>
                                            <option selected value="<?php echo e($data_brand->brand_id); ?>"><?php echo e($data_brand->brand_name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($data_brand->brand_id); ?>"><?php echo e($data_brand->brand_name); ?></option>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Mô tả</label>
                                    <textarea style="resize: none" rows="8" class="form-control" name="product_desc"><?php echo e($data->product_desc); ?></textarea>
                                </div>
                                 <div class="form-group">
                                    <label for="exampleInputPassword1">Nội dung</label>
                                    <textarea style="resize: none" rows="8" class="form-control" name="product_content"><?php echo e($data->product_content); ?></textarea>
                                </div>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <button type="submit" name="update_product" class="btn btn-info">Cập Nhập</button>
                            </form>
                            </div>

                        </div>
                    </section>

            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\locdz\resources\views/admin/update_product.blade.php ENDPATH**/ ?>